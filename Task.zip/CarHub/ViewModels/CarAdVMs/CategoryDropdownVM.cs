﻿namespace CarHub.ViewModels.CarAdVMs
{
    public class CategoryDropdownVM
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
    }
}
